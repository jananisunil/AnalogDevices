import pandas as pd
import os.path
import sys


sourceFile = 'ip.csv'
targetFile = 'op.csv'
headers = ['Time', 'Board Number', 'Parameter', 'Value', '', '','']
cell_value=[]
search_criteria_value = int(input("Enter the column to be sorted. Choose from the following: "
                        "\n%s 0\n%s 1\n%s 2\n%s 3\n"
                        % (headers[0], headers[1], headers[2], headers[3])))
search_criteria= headers[search_criteria_value]

def ReadSortCriteriaFromUser():
    """
    A function that reads the name of columns that need to be sorted
    :return:
    """
    sort_number = int(input("Please enter the number of elements to be arranged"))
    print('Please enter the value of the chosen column one-by-one followed by "Enter Key"')
    for i in range(0, sort_number):
        ele = input()
        cell_value.append(ele.upper())  # adding the element

def CheckEnteredData(df):
    """
    A function that checks if the user entered data is present in the column chosen
    :param df:
    :return:
    """
    for k in cell_value:
        if(df[search_criteria].str.contains(k , na=False).any() ):
            print("%s is available!"%(k))
        else:
            print("Sorry ! %s is not in the chosen column. Please check column '%s' for the value to be entered"%(k, search_criteria))
            sys.exit(0)
    FindColumns(df)
def ReadData(fromFile):
    """
    Reads the data from thr source file based on the criteria mentioned by the user
    :param fromFile: path of the source file
    :return:
    """
    if(os.path.isfile(fromFile)):
        print("Source File Exists")
        readData = pd.read_csv(fromFile,header= None)
        readData.columns = headers
        df = pd.DataFrame(data=readData)
        CheckEnteredData(df)
    else:
        print("Sorry, source file does not exist")

def FindColumns(df):
    """
    Finds columns secific to the user defined criteria
    :param df: dataframe of rows available in the csv along with headers
    :return:
    """
    df2= pd.DataFrame()
    for i in cell_value:
        df1= df.loc[df[search_criteria] == i]
        df2 = df2.append(df1)
    WriteData(df2, targetFile)

def WriteData(filteredrows,toFile):
    """
    Write the value parameter of the data to the destination file
    :param filteredrows: rows selected by the user to be copied to the destination file
    :param toFile: path of the destination file
    :return:
    """
    if (os.path.isfile(toFile)):
        print("Destination File Exists"),
        f = open(toFile, 'w')
        print(filteredrows)
        print("The above shown are the rows selected by you")
        timeStamp =set(filteredrows.iloc[:,0])
        print(timeStamp)
        for j in timeStamp:
            f.write('\n'+j+",")
            df1 = filteredrows.loc[filteredrows['Time'] == j, 'Value']
            for k in df1:
                f.write('\t'+k+",")
        print("Done Copying !")
    else:
        print("Sorry, destination file does not exist.")


if __name__=="__main__":
    ReadSortCriteriaFromUser()
    ReadData(sourceFile)
